#include "games_header.h"

int main ()
{
    UnitTest prime;
    prime.runTest();
} // end of main function